/*********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Program for the 8051 for flashing LED at regular intervals of a pin 
                        in PORT P0 (generic version) by using hardware timer.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : not suitable for exact accuracy of desired time delay.

NOTE                  : LED at 5th pin is connected on the port, LED_PORT.
                        

CHANGE LOGS            :

*****************************************************************************/	

#include "main.h"
#include "delay_t0.h"

/*----------- Public variable defination ------------ */ 
bit LED_state_G;	 
/* portable timer Delay for approx 500 msec for use with steps of approx 1msec  */	
#define   TIMER_DELAY_MSEC    500 	
/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :  LED glows on for 1.5 sec and switiched off for 1.5 sec 

INPUT          : none

OUTPUT         : LED glows on for 1.5 sec and switiched off for 1.5 sec 

NOTE           : on run time, analyze the time delay by using performance analyzer
                 for func, DELAY_HARDWARE_One_Second and DELAY_T0_Wait. Make sure
								 that target has been configured with same Oscilation frequency of 
								 target as of OSC_FREQ.
								 configure target project's Oscilation frequency in project menu, 
								 click 'options on target'. 
-*------------------------------------------------------------*/
void main(void)
{
LED_FLASH_Init();
while(1)
{
// Change the LED state (OFF to ON, or vice versa)
LED_FLASH_Change_State();
/* fixed timer delay of approx 1000 msec by non portable hardware delay
	  by using OSC_FREQ of 12Mhz and OSC_PER_INSC as 12 */
DELAY_HARDWARE_One_Second();
// portable timer Delay for approx 500 msec  */
DELAY_T0_Wait(TIMER_DELAY_MSEC);	
}
}	
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
