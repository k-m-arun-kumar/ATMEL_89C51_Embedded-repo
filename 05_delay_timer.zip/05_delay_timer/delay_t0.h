/**************************************************************************
   FILE          :    delay_t0.h
	 
   PURPOSE       :    Type declarations for the delay_t0.c
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
 KNOWN BUGS      :
 
  NOTE           :   delay_t0.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _DELAY_TO_H
#define _DELAY_TO_H

/* public constants, variables and function prototypes are recoginized and accessed by 
 any functions defined in .c file and  this file must be included in .c file.
 for public variables, functions must not define same public variable name, else only auto 
 or  static variable defination in that function will  access for that same varible name */
 
extern bit LED_state_G;
/* ********************** public function prototype ****************/ 
void LED_FLASH_Init(void);
void LED_FLASH_Change_State(void);
void DELAY_HARDWARE_One_Second(void);
void DELAY_HARDWARE_50ms(void);
void DELAY_T0_Wait(const tWord Num_ms);
#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
