/* ********************************************************************
FILE                 : delay_t0.c

PURPOSE              : portable hardware timer delay of around 1 msec by status check.   
                     Define Timer 0 / Timer 1 reload values for ~1 sec delay. 
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           :  not suitable for exact accuracy of desired time delay.

NOTE                 : Duration of function is highly variable!
                       refer book embedded C  by PONT on 6.2 section

CHANGE LOGS          :

*****************************************************************************/	
#include "main.h"
#include "port.h"
#include "delay_t0.h"

// ------ Private constants -----------------------------------
/* Timer preload values for use in simple (hardware) delays
  NOTE: These values are portable but timings are *approximate*
 and *must* be checked by hand if accurate timing is  required.
 Define Timer 0 / Timer 1 reload values for ~1 msec delay.


/* time unit of resolution of timer.  eg for 1 msec resolution of Timer 2 delay,
   TIME_UNIT = 1000, as  1 / TIME_UNIT = 1 msec. For 20 msec resolution of Timer 2 delay, 
  TIME_UNIT = 50 as 1/50 = 20 msec. All above case, overhead of function call is not included.
 NOTE: Adjustment made to allow for function call overheard etc., esp when status check of Timer is used */
/* for 1000(desired TIME_UNIT ) + 20 (adjustment for overhead), so for TIME_UNIT = 1020,
    we get approx 1 msec resolution of Timer */
 #define TIME_UNIT (1020UL)
 
/* () is required to avoid wrong execution. eg if #define PRELOAD01 65536 - ...* TIME_DELAY , 
   then PRELOAD01/256 is equivalent to 65536 - .. * TIME_DELAY /256, causes TIME_DELAY /256 
	  be executed, which is not desired, so () is required */ 
	
#define PRELOAD01H (tByte)(PRELOAD01 / 256)
/* lower order byte(8bit) of 16 bit timer */
#define PRELOAD01L (tByte)(PRELOAD01 % 256)
/* num of timer delay is in milli second */
#define TICK_MS              (1UL)

/* Logic of LED, depending on HW interfacng the led pin */
#define ON                   (1)
#define OFF                  (0)

/*------------------------------------------------------------*-
FUNCTION NAME      : .DELAY_T0_Wait

DESCRIPTION        : portable timer delay to generate Num_ms millisecond delay (approx)

INPUT              : Delay value Num_ms in msec 

OUTPUT             : produces approx for N msec delay

NOTE               : Uses Timer 0 for delay (easily adapted to Timer 1).
                      
										 Timer T0 are 16-bit, manual reload ('one shot') by using Mode 1.
										 preload values of timer's values are portable but timings are *approximate*
                     and *must* be checked by hand if accurate timing is required.
										 Max system tick interval is ~65ms (12 MHz oscillator).
-*------------------------------------------------------------*/
void DELAY_T0_Wait(const tWord Num_ms)
{
tWord ms, Reload_16;
tLong Inc;
tByte Reload_08H, Reload_08L;
	
	/* OSC_PER_INST = number of oscilation to increment a count in a timer. 
   Reload_16  = Timer preload value for approx 1 ms delay */ 
	
// Number of timer increments required (max 65536)
 Inc = (tLong)((TICK_MS * OSC_FREQ)/(tLong)(TIME_UNIT * OSC_PER_INST));   
/* 2^16 = 65536 max value of 16 bit timer */
// 16-bit reload value
 Reload_16 = (tWord) (65536UL - Inc);
	 
/* high order byte(8bit) of 16 bit timer */
/* 2^8 = 256 */
// 8-bit reload values (High & Low)
Reload_08H = (tByte)(Reload_16 / 256);
Reload_08L = (tByte)(Reload_16 % 256);

// Used for manually checking timing (in simulator) by using preload value for Timer 0
  RELOADH_PORT = Reload_08H;
   RELOADL_PORT = Reload_08L; 	
// Delay value is *approximately* 1 ms per loop
for (ms = 0; ms < Num_ms; ms++)
{
TH0 = Reload_08H;
TL0 = Reload_08L;
TF0 = 0; // clear overflow flag
TR0 = 1; // start timer 0
/*	the overflow of a timer can be used to generate an interrupt, 
	for status check, interrupt of overflow timer is to be dsabled, somewhere before this,
   even if i	*/
/* Loop until Timer 0 has count value 65535, then overflows (TF0 == 1) by status check
	They need to be manually cleared (set to 0) by the programmer. */
while (TF0 == 0); 
TR0 = 0; // Stop Timer 0
}
/* at last, timer 0 overflow flag must be cleared. */
TF0 = 0; // clear overflow flag
}

/*------------------------------------------------------------*-
FUNCTION NAME      : LED_FLASH_Init

DESCRIPTION        : state of LED pin is OFF initially and configure the Timer mode.
                     and disable interrupt from timer T0 due to overflow

INPUT              : 

OUTPUT             : 

NOTE               : Prepare for LED_Change_State() function.
                     we assume that timer mode are not required
                     to change after been configured 
-*------------------------------------------------------------*/
void LED_FLASH_Init(void)
{
LED_state_G = 0;
// Configure Timer 0 as a 16-bit timer
ET0 = 0; // No interrupts been generated by timer 0	when timer count reaches 65535
// Configure Timer 0 as a 16-bit timer. Clear all T0 bits (T1 left unchanged)
TMOD &= 0xF0; 
/* Set required T0 bits (T1 left unchanged) with mode 1, 16-bit timer (with manual reload)	
	Gate bit is cleared, which means that Timer 0 will be enabled whenever the corresponding 
	control bit (TR0) is set in the TCON SFR.*/
TMOD |= 0x01;
	
/* only LED pin is cleared and all other pins of port 0 are unaffected. 
	  so LED_PORT's pins is 0xDF */	
/* when only led_pin = PIN_LED(5) and logic 0, used for led to switch off, this is fine.
   	But when we change led pin other than 5 or logic 0 is used for led to flash on,
	  then below statement causes incorrect operation */	
/* LED_PORT &= 0xDF; */
	
 
  /* To function, a positive voltage should be supplied to the common anode
 	and for the common cathode should be grounded. Single led in a segment is illuminated 
	by application of a �HIGH�, or logic �1� signal, in the Common Cathode. 
	In common anode, single led in a segment is lluminated by applying a ground, logic �0� 
	or �LOW�, refer http://www.electronics-tutorials.ws/blog/7-segment-display-tutorial.html , 
	for more info on 7 segment display. */	
	/* led is switched off */
	/* this is the best solution, which is independent of PIN_LED and logic used to switch off led. */
	LED_pin = OFF;
}
/*------------------------------------------------------------*-
FUNCTION NAME      : LED_FLASH_Change_State

DESCRIPTION        : Changes the state of an LED (or pulses a buzzer, etc) on a
specified port pin. Must call at twice the required flash rate: thus, for 1 Hz
flash (on for 0.5 seconds, off for 0.5 seconds) must call every 0.5 seconds.

INPUT              : 

OUTPUT             : 

NOTE               : 
-*------------------------------------------------------------*/
void LED_FLASH_Change_State(void)
{
// LED switched from ON to OFF 
if (LED_state_G == 1)
{
LED_state_G = 0;
LED_pin = OFF;
}
//LED flashes from OFF to ON
else
{
LED_state_G = 1;
LED_pin = ON;
}
}
/*------------------------------------------------------------*-
FUNCTION NAME      : DELAY_HARDWARE_One_Second

DESCRIPTION        : by using Timer, Hardware delay of 1000 ms.

INPUT              : 

OUTPUT             : 

NOTE               : Assumes 12MHz 8051 (12 osc cycles)
-*------------------------------------------------------------*/
void DELAY_HARDWARE_One_Second(void)
{
unsigned char d;
// Call DELAY_HARDWARE_50ms() twenty times
for (d = 0; d < 20; d++)
{
DELAY_HARDWARE_50ms();
}
}
/*------------------------------------------------------------*-
FUNCTION NAME      : DELAY_HARDWARE_50ms

DESCRIPTION        : by using Timer, Hardware delay of 50 ms.

INPUT              : 

OUTPUT             : 

NOTE               : Assumes 12MHz 8051 (12 osc cycles).
                     Uses Timer 0 for delay (easily adapted to Timer 1).
-*------------------------------------------------------------*/
void DELAY_HARDWARE_50ms(void)
{
// Values for 50 ms delay
TH0 = 0x3C; // Timer 0 initial value (High Byte)
TL0 = 0xB0; // Timer 0 initial value (Low Byte)
TF0 = 0; // Clear overflow flag
TR0 = 1; // Start timer 0
while (TF0 == 0); // Loop until Timer 0 overflows (TF0 == 1)
TR0 = 0; // Stop Timer 0
TF0 = 0; // Clear overflow flag	
}
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
