/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

/* for demo purpose only, CTRL_PORT is used to display current state of system. */
#define CTRL_PORT  P2
#define SLEEP_PIN  (0) 
#define WAKE_PIN  (1)
#define GROWL_PIN (2)
#define ATTACK_PIN (3)
/* corresponding pin flashs on corresoinding to the current state of system ,
   ie, when current state of system = sleep, sleep_pin is flashs on and other CTRL_port
	 pins of system is switched off */
sbit sleep_pin = CTRL_PORT^SLEEP_PIN;
sbit wake_pin = CTRL_PORT^WAKE_PIN;
sbit growl_pin = CTRL_PORT^GROWL_PIN;
sbit attack_pin = CTRL_PORT^ATTACK_PIN;

// Used for manually checking timing (in simulator) by using preload value for Timer 2. used for test purpose
#define RELOADH_PORT P1
#define RELOADL_PORT P0

#endif 

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
