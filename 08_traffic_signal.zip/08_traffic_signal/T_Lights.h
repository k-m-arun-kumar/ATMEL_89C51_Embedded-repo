/**************************************************************************
   FILE          :    T_Lights.h
	 
   PURPOSE       :    Type declarations for the T_Lights.c
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
 KNOWN BUGS      :
 
  NOTE           :   T_Lights.c for details. 
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 #ifndef _T_LIGHTS_H
#define _T_LIGHTS_H

// ------ Public data type declarations ----------------------------

// possible system states. In traffic signal system, there are 3 possible states.
typedef enum {RED, GREEN, YELLOW } eLight_State;

// ------ Public function prototypes -------------------------------

void TRAFFIC_LIGHTS_Init(const eLight_State);
void TRAFFIC_LIGHTS_Update(void);

void Red_State(void);
void Green_State(void);
void Yellow_State(void);

/* -------------- Public data constants ----------------- */
/* system ticks interval in m sec. for Every TICK_INTERVAL, application Task followed by e0S(system Task)
   is executed. NOTE: make sure that SYSTEM_TICK_INTERVAL is large enough that uC executing maximum time 
	 required to start and completes executing Application task and system task(sEOS_Go_To_Sleep) 	*/
	 
#define SYSTEM_TICK_INTERVAL  (50U)

#endif

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
