/* ********************************************************************
FILE                 : T_Lights.c

PURPOSE              : Traffic light control program.
                       Initial state of traffic system is set and implements FSM of traffic system. 
											 traffic light are displayed ,updated and FSM is processed every UPDATE_PERIOD.
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : FSM of traffic system is only time driven, so inputs from outside or inside 
									     does not affect behaviour of traffic system, so it highly predicatible.
											 

CHANGE LOGS          :

*****************************************************************************/
#include "main.h"
#include "port.h"

#include "T_Lights.h"

// ------ Private constants ----------------------------------------

/* Easy to change logic required by interfacing hardware connected to Traffic port pins of uC */
#define ON  (1)
#define OFF (0)

// Times in each of the (three) possible traffic light states
// (Times are in seconds)
#define RED_DURATION     (20UL)
#define GREEN_DURATION    (30UL)
#define YELLOW_DURATION    (5UL)


// ------ Private variables ----------------------------------------

// The present state of the traffic system
static eLight_State Light_state_G;

/* instanteous total time stayed in that state, in steps of UPDATE_PERIOD. 
 Must reset when change of state occurs and starts counting in new state */  
static tLong Time_in_state;


/*------------------------------------------------------------*-
FUNCTION NAME  : TRAFFIC_LIGHTS_Init

DESCRIPTION    : Prepare for the traffic light activity.
                 initial state of traffic system = START_STATE 

INPUT          : START_STATE is initial state that traffic system starts from.

OUTPUT         : 

NOTE           : for counter, initialize counter
-*------------------------------------------------------------*/
void TRAFFIC_LIGHTS_Init(const eLight_State START_STATE)
   {
		// Decide on initial state,  
   Light_state_G = START_STATE;      		 
		 
   }

/*------------------------------------------------------------*-
FUNCTION NAME  : TRAFFIC_LIGHTS_Update

DESCRIPTION    :  Traffic lights are displayed. Finite state machine of traffic system is
	                implemented.      .
              	 1: when uC resets, traffic system state is RED state,
	               2: traffic system stays in red for duration of RED_DURATION,
                	 then changes state to GREEN. 	 
	               3: traffic system stays in green for duration of GREEN_DURATION, 
	                then changes state to YELLOW.
	               4:	traffic system stays in YELLOW for duration of YELLOW_DURATION, 
	                then changes state to RED.
	               5: go to step 2 and repeats.  
INPUT          :  current state and instanteous of total time duration stayed in a particular state of traffic system.

OUTPUT         : traffic lights are displayed.

NOTE           : Must be called once every UPDATE_PERIOD.
	              System states will usually be represented by means of a
	              switch statement in the operating system ISR.  
-*------------------------------------------------------------*/
void TRAFFIC_LIGHTS_Update(void)
   {
   switch (Light_state_G)
      {
		/* current system state = RED */		
      case RED: 
         {
		  	/* for red state, action is to be taken  */		 
         Red_State();
				
        /* if instanteous total time stayed in RED reachs predeterminted max of red duration,
           resets Time_in_state var and change the traffic system state to Green, so next time 
					 TRAFFIC_LIGHTS_Update() is called,  Time_in_state var increments by 1 and state is Green,
         and  process repeats */
         if (++Time_in_state >= RED_DURATION)
            {
            Light_state_G = GREEN;
            Time_in_state = 0;
            }

         break;
         }    
      /* current system state = GREEN */
      case GREEN: 
         {
			   /* for green state, action is to be taken  */		
          Green_State();
		      /* if instanteous total time stayed in GREEN reachs predeterminted max of green duration,
           resets Time_in_state var and change the traffic system state to yellow, so next time 
					 TRAFFIC_LIGHTS_Update() is called,  Time_in_state increments by 1 and state is yellow,
        and  process repeats */			 
         if (++Time_in_state >= GREEN_DURATION)
            {
            Light_state_G = YELLOW;
            Time_in_state = 0;
            }

         break;
         }
  /* current system state = YELLOW */
      case YELLOW: 
         {
			/* for yellow state, action is to be taken  */				 
           Yellow_State();
				 /* if instanteous total time stayed in yellow reachs predeterminted max of yellow duration,
           resets Time_in_state var and change the traffic system state to red, so next time 
					 TRAFFIC_LIGHTS_Update() is called,  Time_in_state increments by 1 and state is red,
         and process repeats */		 
         if (++Time_in_state >= YELLOW_DURATION)
            {
            Light_state_G = RED;
            Time_in_state = 0;
            }

         break;
         }
      }
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : Red_State

DESCRIPTION    : acton are taken, when system is in Red state.
                 Red light flashes on. green and yellow lights are switch off	 

INPUT          : 

OUTPUT         : 

NOTE           :
-*------------------------------------------------------------*/	 
void Red_State(void)
{
	 Red_light = ON;
   Green_light = OFF;
	 Yellow_light = OFF; 
}	

/*------------------------------------------------------------*-
FUNCTION NAME  : Green_State

DESCRIPTION    : action are taken, when system is in green state.
                 green light flashes on. red and yellow lights are switch off	 

INPUT          : 

OUTPUT         : 

NOTE           :
-*------------------------------------------------------------*/	 
void Green_State(void)
{
	 Red_light = OFF;
   Green_light = ON;
	 Yellow_light = OFF; 
}	
/*------------------------------------------------------------*-
FUNCTION NAME  : Yellow_State

DESCRIPTION    : action are taken, when system is in yellpw state.
                 yellow light flashes on. red and green lights are switch off	 

INPUT          : 

OUTPUT         : 

NOTE           :
-*------------------------------------------------------------*/	 
void Yellow_State(void)
{
	 Red_light = OFF;
   Green_light = OFF;
	 Yellow_light = ON; 
}	
/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
