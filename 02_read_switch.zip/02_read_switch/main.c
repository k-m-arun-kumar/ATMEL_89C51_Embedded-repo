/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Program for the 8051 for reading the data from READ_PORT PORT and 
                         write READ_PORT port's data to WRITE_PORT port as data.
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : input parallel port is connected to READ_PORT
                       and output parallel port is connected to WRITE_PORT

IMPORTANT     : switch pin in a port or as whole port should always be at its corresponding pin or whole port 
               respectively to 1 for prior to reading. eg if only P3.2 is used as input, then prior to reading P3.2
							 then P3 = 00000100, is essential. if P3 as whole is used as input port, then P3 =0xFF  is essential.
                it is safer to always write �1� to any port pin before reading from it. 
	   If switch_pin set to 0 by any means and reading from that pin cause program to crash.
     It can damage the uC, if it is downloaded and executed in uC.
		 
CHANGE LOGS            :

*****************************************************************************/	
/* main.h is a ( as indicated by "") user specific header file located in same directory as main.c is present. 
  preprocessor searchs main.h ( as indicated by "") in same directory as main.c is present and attaches it with main.c */
#include "main.h"
#include "port.h"
#include "read_write.h"

/********* private function prototype **************/
void Switch_Init(void);


/*-------------------------------------------------------------
FUNCTION NAME  : main

DESCRIPTION    :  initialize switch port to read. indefinetely read the status
                  of switch and write status of switch to output parallel port.              

INPUT          : none

OUTPUT         : status of switch in READ_PORT port is updated to output parellel port in WRITE_PORT port.

NOTE           : 
-------------------------------------------------------------*/
void main()
{
	tByte Switch_data = 0x00;
	Switch_Init();
	while(1) // super loop
	{
	   Switch_data = Read_Switch();
	   Write_Port(Switch_data);
	}		
}

/*-------------------------------------------------------------
FUNCTION NAME  : Switch_Init

DESCRIPTION    :  initialize switch port, READ_PORT for reading.               

INPUT          : none

OUTPUT         : switch port, READ_PORT for reading is set to 0xFF

NOTE           : essential to initialize READ_PORT or part of port's pin to set it
  for read mode in input port as 1. 
 in our case READ_PORT as whole(8 bit) is set to 0xFF to set READ_PORT for reading.
   
-------------------------------------------------------------*/
void Switch_Init(void)
{
	READ_PORT = 0xFF;	
}


/*------------------------------------------------------------*-
------------------------- END OF FILE --------------------------
-*------------------------------------------------------------*/
