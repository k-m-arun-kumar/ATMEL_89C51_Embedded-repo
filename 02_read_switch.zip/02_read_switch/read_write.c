/*********************************************************************
FILE                  : read_write.c

PURPOSE               : user specific library program for reading and writing from and 
                         to a READ_PORT and to WRITE_PORT, respectively.
												 
                         write the data to WRITE_PORT port from given DATA
                        read the data feeded from READ_PORT port
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :

NOTE                  : 

CHANGE LOGS           :

*****************************************************************************/ 
#include "main.h"
#include "port.h"
#include "read_write.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : Read_Switch

DESCRIPTION    : read the data feeded from READ_PORT port               

INPUT          : none

OUTPUT         : data from READ_PORT port 

NOTE           : prerequiste -  READ_PORT port as whole(8 bit) has been set as
               0xFF to make READ_PORT as input prior to reading.

IMPORTANT     : Pins of READ_PORT port in simulator is used to change the data 
     given by READ_PORT. READ_PORT = 0xFF is initialized before and then 
		  if pins of READ_PORT port = 0x25, then WRITE_PORT = 0x25 in this program. 
		 
		  When READ_PORT = 0xFE is initialized before, and 
		 then when READ_PORT.0 pin is changed, then program crashes.
-------------------------------------------------------------*/	
tByte Read_Switch(void)
{
    return READ_PORT;	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Port

DESCRIPTION    : write the data to WRITE_PORT port from given DATA               

INPUT          : DATA to be written to the WRITE_PORT port

OUTPUT         : WRITE_PORT port 

NOTE           :

-------------------------------------------------------------*/	
void	Write_Port(const tByte DATA)
{
	WRITE_PORT = DATA;	
}


/*------------------------------------------------------------*-
------------------------- END OF FILE --------------------------
-*------------------------------------------------------------*/
