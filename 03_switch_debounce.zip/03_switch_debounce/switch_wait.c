/* ********************************************************************
FILE                 : switch_wait.c

PURPOSE              : Simple library for debouncing a switch input.   
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : time delay by debounce and wait timeout is not much fine tuned.

NOTE                 : Duration of function is highly variable!

CHANGE LOGS          :  follow TIMEOUT code segment  .

*****************************************************************************/	

#include "main.h"
#include "port.h"
#include "switch_wait.h"

// ------ Private function prototypes -------------------------
/* private DELAY_LOOP_Wait() only switch_wait.c, this file will only access this function
  other files cannot access this function, if is file is not included by #include directive.
  usually, only header file(.h) is included by #include directive. public (global) function prototype,
	data type,  variables and constants are defined and/or declared in .h file. external storage variable is 
	considered as public. Private function prototypes, private data types, private variables and constants
	are defined and/or declared in same .c file. static and auto storage variable and function
	are accessed only in same file and same function respectively  */
static void DELAY_LOOP_Wait(const tWord DELAY_MS);

/* depending on HW interfacing the led pin, logic 0 or logic 1 causes led to glow on.*/
/* in our case, logic 1 causes led to glow on */
#define ON (1)
/* logic 0 causes led to switch off */
#define OFF (0)

/*------------------------------------------------------------*-
FUNCTION NAME : SWITCH_Init

DESCRIPTION   : Initialisation function for the switch library.

INPUT         : none

OUTPUT        : initialize port P0, such that input pins are always 
                set to 1.

IMPORTANT     : switch pin should always be set to 1 prior to reading.
                it is safer to always write �1� to any port pin before reading from it. 
	   If switch_pin set to 0 by any means and reading of that pin cause program to crash.
     It can damage the uC if it is downloaded and executed in uC.

-*------------------------------------------------------------*/
void SWITCH_Init(void)
{
	/* switch pin must be configured as input by setting as 1, as 0 is consided as switch been pressed on. */
	   
	/* reset uC automatically causes all ports and pins are set as 0xFF */
	//  LED_SWITCH_PORT = 0x20;
	
	switch_pin = 1;
	led_pin = OFF;
	led_switch_pin = OFF;
	timeout_pin = OFF;
	
}	
/*------------------------------------------------------------*-
FUNCTION NAME  : SWITCH_Get_Input()

DESCRPTION     : Reads and debounces a mechanical switch as follows:
1. If switch is not pressed, return SWITCH_NOT_PRESSED.
2. If switch is pressed, wait for DEBOUNCE_PERIOD (in ms).
a. If switch is released before DEBOUNCE_PERIOD, return SWITCH_NOT_PRESSED.
b. If switch is still pressed on, wait (with timeout of approx 10 sec) for
switch to be released. If it times out,then return SWITCH_NOT_PRESSED:
c. for switch been released within timeout of approx 10 sec, after debounce, then return SWITCH_PRESSED.
Corresponding led_switch and led_pin state are changed, so that switch state  
corresponds to led_switch and led_pin is used to indiate a valid switch press is detected.
timeout pin is used to indicate switch is still pressed on even after timeout of approx 10 sec

INPUT          : DEBOUNCE_PERIOD.

OUTPUT         : whether if switch if pressed is valid or not pressed.

NOTE           :  See switch_wait.h for details of return values
-*------------------------------------------------------------*/
bit SWITCH_Get_Input(const tByte DEBOUNCE_PERIOD)
{
bit Return_value = SWITCH_NOT_PRESSED;
	/* Added for TIMEOUT : begin */	
/* after fine tuning by using TEST define, Timeout_loop has been intialized for timeout of 10 sec */  	
tLong Timeout_loop = LOOP_TIMEOUT_INIT_10000ms;	
	/* add end : TIMEOUT  */	
	
/* depending on HW interfacing the led port, logic 0 or logic 1 causes led to glow on.
	 In this case, logic 1 causes led to glow on, so for state of led_switch_pin is inverse state of switch pin. 
	 switch pin is in state 0, when pressed on, then led_switch_pin should be 1 to indicate that LED glows.
 	*/
	  led_switch_pin = ~switch_pin;
	

/* switch pin is pressed ON by giving 0 value bit to input of P0 Port's */	
if (switch_pin == 0)
{
// Switch is pressed
// Debounce � just wait...
DELAY_LOOP_Wait(DEBOUNCE_PERIOD);
/* Check switch again, if switch is pressed off within debounce period after been turned on, 
	then switch state is considered as not valid, as been not pressed as whole */	
if(switch_pin == 0)
{
	
	/* to avoid repeated indication of switch pressed on after debounce period. eg if switch is pressed on even 
	   after debounce period, without while(), it would have be indicate another key press switch is pressed on 
	   even after debounce period. allow up to 10 seconds to release the switch. if it is not released in timeout
   	period, the while() will �time out� and exit loop and timeout is required to avoid when malfunction of switch after 
	  been pressed on without timeout causes to loop in while (switch_pin == 0) forever  */
	/* added for TIMEOUT : begin */
	led_switch_pin = ON;	
	while (switch_pin == 0 && ++Timeout_loop != 0);
	/* time has expired but still switch is pressed on  */
	if(Timeout_loop == 0)
	{
		timeout_pin = ON;
   	led_switch_pin = ON;		
	}
	else
	{
		 Return_value = SWITCH_PRESSED;
		 timeout_pin = OFF;
		 led_switch_pin = OFF;	
		 led_pin = ON;
	}	
	/* add end : TIMEOUT*/
	/* removed for TIMEOUT  :  begin 
  Return_value = SWITCH_PRESSED;
	led_switch_pin = 1;
	led_pin = 1;   */
	
	/* switch is pressed on even after debounce period. Wait until the switch is released to avoid 
	repeated indication of switch pressed on after debounce period. eg if switch is pressed on even 
	after debounce period, without while(), it would have be indicate another key press */
	
 /* while (switch_pin == 0);	 
	led_switch_pin = 0; 
	remove end : TIMEOUT */
}
}
if(Return_value == SWITCH_NOT_PRESSED)
{
	led_switch_pin = OFF;
	led_pin = OFF;		
}	
// Now (finally) return switch value
return Return_value;
}

/*------------------------------------------------------------*-
FUNCTION NAME      : DELAY_LOOP_Wait.

DESCRIPTION        : Delay duration varies with parameter.
Parameter is, *ROUGHLY*, the delay, in milliseconds,
on 12MHz 8051 (12 osc cycles).

INPUT              : DELAY_MS for to adjust for delay required for switch debounce.

OUTPUT             : led_switch changes it state according to switch.

NOTE               : You need to adjust the timing for your application!

-*------------------------------------------------------------*/
void DELAY_LOOP_Wait(const tWord DELAY_MS)
{
tWord x, y;
for (x = 0; x <= DELAY_MS; x++)
{	
	for (y = 0; y <= 120; y++);
	/* state of led_switch_pin is inverse state of switch. switch is in state 0,
  	when pressed, then led pin should be 1 to indicate on */
	  led_switch_pin = ~switch_pin;
}
}
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
