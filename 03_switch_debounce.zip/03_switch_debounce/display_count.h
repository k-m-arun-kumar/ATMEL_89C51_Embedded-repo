/**************************************************************************
   FILE          :    display_count.h
 
   PURPOSE       :    Type declarations for the display_count.c
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    display_count.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/

#ifndef _DISPLAY_COUNT_H
#define _DISPLAY_COUNT_H
// ------ Public function prototypes --------------------------
void DISPLAY_COUNT_Init(void);
void DISPLAY_COUNT_Update(const tByte);
#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
