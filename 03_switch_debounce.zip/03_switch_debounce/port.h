/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     : TIMEOUT code segment is added. 
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H
/* main.h is the one of the header file (user specified header file) of your own program. 
  For "" enclosed, preprocessor will look for the main.h in the same directory as the source file,
   to locate main.h and attaches main.h with main.c*/
#include "main.h"
#define LED_SWITCH_PORT P2
/* Switch is physically connected to PORT P2, whose pin is 5. pin 0 is least and pin 7 is the most for a 8bit P2 port */
/* sbit does not allocate memory for switch_pin. bit memory of switch_pin is a part of memory address of P0 port  */
sbit switch_pin =LED_SWITCH_PORT ^5;
/* LED is physically connected to PORT P0, whose pin is 2. led is used to indicate the switch is detected as valid */
sbit led_pin  = LED_SWITCH_PORT^2;
/* LED is physically connected to PORT P0, whose pin is 0. led is used to indicate the state of switch  */
sbit led_switch_pin = LED_SWITCH_PORT^0;
/*  Added for TIMEOUT: begin */
/* LED is physically connected to PORT P0, whose pin is 7. led is used to indicate the timeout occurs after debounce and switch is still pressed on */
sbit timeout_pin = LED_SWITCH_PORT^7; 
/* TIMEOUT: end */
/* P1 port is physically connected to parallel device, which receives and displays number of times switch is on and off */
#define  COUNT_PORT  P1

#endif
