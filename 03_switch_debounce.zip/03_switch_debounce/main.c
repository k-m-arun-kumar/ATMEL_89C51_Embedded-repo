/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :   program for the 8051 with switch debounce.
 current state of switch is given to led switch pin. if switch pressed on
	 is valid, then indicate to another led. Display the total number 
	 of times the switch pressed on is valid to the another port. 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
	 KNOWN BUGS            : 1: time required to indicate LED on and OFF is not considered. 
If is considered that LED changes its state immediately, as response time of LED's
is considered as almost 0.To fix this issue, appropiate time delay should be given 
to LED between change of LED's state, esp led_pin.

2: time delay by debounce and wait timeout is not much fine tuned.

NOTE                  : 

CHANGE LOGS           : TEST code segment is used to fine tune software timeout of approx 10 sec 

*****************************************************************************/	

#include "main.h"
#include "port.h"
#include "switch_wait.h"
#include "display_count.h"

/************ Private CONSTANTS DEFINATION **************************************/
/* only main.c, this file recogonize the private CONSTANT definations, so it must be defined in .c file */
/* DEBOUNCE_PARA must be value that debounce period is 100 ms and if switch is still pressed on ,
  then valid press of switch has been detected */
#define DEBOUNCE_PARA    50

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :  initialize ports required for this program, then
 indefinely executes switch press detection and if the switch pressed on and then off is
 valid,then  increment the total number of valid switch press on and off and display it to
output port. 

INPUT          : none

OUTPUT         : led_switch and led_pin are updated.

NOTE           : 
-*------------------------------------------------------------*/
void main(void)
{
/* number of times switch has be valid pressed. switch_presses variable 
	 is memory allocated in on chip RAM of uC or in external RAM */
tByte Switch_presses = 0;

// Init functions
SWITCH_Init();
DISPLAY_COUNT_Init();

while(1)
{
	#ifndef TEST    
	   
	  
	  if (SWITCH_Get_Input(DEBOUNCE_PARA) == SWITCH_PRESSED)
		{	
			 Switch_presses++;			 
		}	
    DISPLAY_COUNT_Update(Switch_presses);   
	#else	
	   Test_Timeout();
	#endif	
}
}
#ifdef TEST
/*------------------------------------------------------------*-
FUNCTION NAME  : Test_Timeout

DESCRIPTION    : test to check software timeout for 10 sec 

INPUT          : none

OUTPUT         : 

NOTE           : only used to fine tune LOOP_TIMEOUT_INIT_10000ms 
                 value for timeout of 10sec
-*------------------------------------------------------------*/
void Test_Timeout(void)
{
tLong Timeout_loop = LOOP_TIMEOUT_INIT_10000ms;
// Simple loop timeout...
while (++Timeout_loop != 0);
}
#endif
/*------------------------------------------------------------
---- END OF FILE --------------------------------------------
------------------------------------------------------------*/
