/* ********************************************************************
FILE                   : PC_O_T1.c

PROGRAM DESCRIPTION    :  Simple write-only PC link library Version A (generic)
   [Sends data to PC - cannot receive data from PC] via RS 232 link
                      									 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :  Uses the UART, and Pin 3.1 (Tx) 											
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "PC_O_T1.h"

// ------ Public variable declarations -----------------------------

extern tByte Out_written_index_G;  
extern tByte Out_waiting_index_G;  

/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Init_T1

DESCRIPTION    : This version uses T1 Timer for baud rate generation.
								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           :  
-*------------------------------------------------------------*/

void PC_LINK_O_Init_T1(const tWord BAUD_RATE)
   {
   PCON &= 0x7F;   // Set SMOD bit to 0 (don't double baud rates)

   //  Receiver disabled
   //  8-bit data, 1 start bit, 1 stop bit, variable baud rate (asynchronous)
   SCON = 0x42;

   TMOD |= 0x20;   // T1 in mode 2, 8-bit auto reload

	/* The baud rate is determined by the Timer 1 overflow rate and the value of SMOD as follows:
 		 Baud rate (Mode 1) = 2^SMOD � oscillator freq / 32 � Instruction cycle � (256 � TH1)	
		 
 SMOD is the �double baud rate� bit in the PCON register;
 oscillator freq (OSC_FREQ) is the oscillator / resonator frequency (in Hz);
 Instruction cycle (OSC_PER_INST ) is the number of machine instructions per oscillator cycle (e.g. 12 or 6)
 TH1 is the reload value for Timer 1		 */ 
		 
   TH1 = (256 - (tByte)((((tLong)OSC_FREQ / 100) * 3125) 
            / ((tLong) BAUD_RATE * OSC_PER_INST * 1000)));

   TL1 = TH1;  
   TR1 = 1;  // Run the timer
   TI = 1;   // Send first character (dummy)

   // Set up the buffers for reading and writing
   Out_written_index_G = 0;
   Out_waiting_index_G = 0;
	 
  /* serial port interrupts are disabled */
   ES = 0;
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
