/* ********************************************************************
FILE                   : PC_O.c

PROGRAM DESCRIPTION    :  Core files for simple write-only PC link library for 8051 family
                          [Sends data to PC - cannot receive data from PC]. Uses the UART, and Pin 3.1 (Tx) 
                      									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 											
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "PC_O.h"
#include "Elap_232.h"

// ------ Public variable definitions ------------------------------

tByte Out_written_index_G;  // Data in buffer that has been written 
tByte Out_waiting_index_G;  // Data in buffer not yet written

// ------ Private function prototypes ------------------------------

static void PC_LINK_O_Send_Char(const char);

// ------ Private constants ----------------------------------------

// The transmit buffer length
#define TRAN_BUFFER_LENGTH 20

// ------ Private variables ----------------------------------------

static tByte Tran_buffer[TRAN_BUFFER_LENGTH];

static tByte Time_count_G = 0;

/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Update

DESCRIPTION    : Sends next character from the software transmit buffer
								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           :  Output-only library (Cannot receive chars)
-*------------------------------------------------------------*/
void PC_LINK_O_Update(void)
   {
   // Deal with transmit bytes here
   //
   // Are there any data ready to send?
   if (Out_written_index_G < Out_waiting_index_G)
      {
      PC_LINK_O_Send_Char(Tran_buffer[Out_written_index_G]);     

      Out_written_index_G++;
      }
   else
      {
      // No data to send - just reset the buffer index
      Out_waiting_index_G = 0;
      Out_written_index_G = 0;
      }
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Write_String_To_Buffer

DESCRIPTION    : Copies a (null terminated) string to the character buffer.  
								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           : The contents of the buffer are then passed over the serial link
-*------------------------------------------------------------*/

void PC_LINK_O_Write_String_To_Buffer(const char* const STR_PTR)
   {
   tByte i = 0;

   while (STR_PTR[i] != '\0')
      {
      PC_LINK_O_Write_Char_To_Buffer(STR_PTR[i]);
      i++;
      }
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Write_Char_To_Buffer

DESCRIPTION    : Stores a character in the 'write' buffer, ready for 
                later transmission
 								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           : The contents of the buffer are then passed over the serial link
-*------------------------------------------------------------*/
void PC_LINK_O_Write_Char_To_Buffer(const char CHARACTER)
   {
   // Write to the buffer *only* if there is space
   // (No error reporting in this simple library...)
   if (Out_waiting_index_G < TRAN_BUFFER_LENGTH)
      {
      Tran_buffer[Out_waiting_index_G] = CHARACTER;
      Out_waiting_index_G++;     
      }
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Send_Char

DESCRIPTION    : Based on Keil sample code, with added (loop) timeouts.
  Implements Xon / Off for flow control in RS 232.
 								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           : 
-*------------------------------------------------------------*/
void PC_LINK_O_Send_Char(const char CHARACTER)
   {
   tLong Timeout1 = 0;

   if (CHARACTER == '\n')  
      {
      Timeout1 = 0;
      while ((++Timeout1) && (TI == 0));  

      if (Timeout1 == 0)
         {
         // UART did not respond - error
         // No error reporting in this simple library...
         return;
         } 

      TI = 0;
      SBUF = 0x0D;  // Output CR  
      }
  
   Timeout1 = 0;
   while ((++Timeout1) && (TI == 0));  

   if (Timeout1 == 0)
      {
      // UART did not respond - error
      // No error reporting in this simple library...
      return;
      } 

   TI = 0;

   SBUF = CHARACTER;
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
