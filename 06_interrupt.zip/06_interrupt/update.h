/**************************************************************************
   FILE          :    update.h
	 
   PURPOSE       :    Type declarations for the update.c
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
 KNOWN BUGS      :
 
  NOTE           :   update.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _UPDATE_H
#define _UPDATE_H

#include <reg52.h>
/* public constants, variables and function prototypes are recoginized and accessed by 
 any functions defined in .c file and  this file must be included in .c file.
 for public variables, functions must not define same public variable name, else only auto 
 or  static variable defination in that function will  access for that same varible name */
 
/* ********************** public function prototype ****************/ 
void Timer_2_Init(const tByte TICK_MS);
void Update_count(const tByte COUNT);

/* --------------------public variable declaraction -----------------*/
/* state of LED */
extern bit LED_state;
extern tLong interruptT2_count;
#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
