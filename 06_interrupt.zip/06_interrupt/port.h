/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#include <reg52.h>
/* sbit does not allocate memory for switch_pin. bit memory of switch_pin is a part of memory address of P0 port  */
/* LED is physically connected to PORT P0, whose pin is 1.led_pin is used to flash on every 2 timer T2 overflow interrupt occurs */
sbit led_pin = P0^1;

/* P1 port is physically connected to parallel device, which receives and displays number of times switch is on and off */
#define  COUNT_PORT  P1
// Used for manually checking timing (in simulator) by using preload value for Timer 2.
#define RELOADH_PORT P3
#define RELOADL_PORT P2

#endif

/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
