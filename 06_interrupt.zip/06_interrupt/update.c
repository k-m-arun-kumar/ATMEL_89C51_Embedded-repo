/* ********************************************************************
FILE                 : update.c

PURPOSE              : portable hardware timer delay of around 1 msec by interrupt.   
                     configure and intialIze Timer 2 reload and capture register values  
										 and update COUNT_PORT.
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : refer book embedded C  by PONT on 7.2 section

CHANGE LOGS          :

*****************************************************************************/	
#include "main.h"
#include "port.h"
#include "update.h"

/* time unit of system tick interval.  eg for 1 msec resolution of Timer 2 delay,
   TIME_UNIT = 1000, as  1 / TIME_UNIT = 1 msec. For 20 msec resolution of Timer 2 delay, 
	 TIME_UNIT = 50 as 1/50 = 20 msec.
SYSTEM_TICK_INTERVAL should be exact multiple of resolution of Timer 2 delay.	 */
#define TIME_UNIT   (1000UL)
 
/* max value that count_port can display. For a 8 bit port, MAX_COUNT must not exceed 255 */ 
 #define MAX_COUNT    (255U)
/*------------------------------------------------------------*-
FUNCTION NAME  : Timer_2_Init

DESCRIPTION    : configure Timer 2 and perodically timer overflow interrupt occurs  

INPUT          : TICK_MS - periodic tick interval that timer2 overflow interrupt occurs.

OUTPUT         : 

NOTE           : after timer T2 overflows, t2 automatically reload values 
                 from capture register and starts running.
                TICK_MS must have Maximum value of ~65 msec for 12MHz oscilation frequency 
-*------------------------------------------------------------*/
void Timer_2_Init(const tByte TICK_MS)
{

// This code (generic 8051/52) assumes a 12 MHz system osc.
// The Timer 2 resolution is then 1.000 �s
//
   tLong Inc;
   tWord Reload_16;
   tByte Reload_08H, Reload_08L;

   /*  Timer 2 is configured as a 16-bit timer, which is automatically reloaded 
		  with recapture register values when it overflows */
   T2CON   = 0x04;   // Load Timer 2 control register

// Number of timer increments required (max 65536)
   Inc = (tLong)((TICK_MS * OSC_FREQ)/(tLong)(TIME_UNIT * OSC_PER_INST)); 

   // 16-bit reload value
   Reload_16 = (tWord) (65536UL - Inc);

   // 8-bit reload values (High & Low)
   Reload_08H = (tByte)(Reload_16 / 256);
   Reload_08L = (tByte)(Reload_16 % 256);

   // Used for manually checking timing (in simulator) by using preload value for Timer 2
 /*  RELOADH_PORT = Reload_08H;
   RELOADL_PORT = Reload_08L; */

   TH2     = Reload_08H;   // Load Timer 2 high byte
   RCAP2H  = Reload_08H;   // Load Timer 2 reload capture register high byte
   TL2     = Reload_08L;   // Load Timer 2 low byte
   RCAP2L  = Reload_08L;   // Load Timer 2 reload capture register low byte
// Timer 2 interrupt is enabled, and ISR will be called
// whenever the timer overflows � see below.
ET2 = 1; // enable timer 2 to interrupt 8051/8052 when overflow occurs
// Start Timer 2 running
TR2 = 1;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Update_count()

DESCRIPTION     : display tByte data (COUNT) on LEDs connected to port COUNT_PORT.

INPUT          : total number of times timer T2 overflow interrupts occurs exactly divided by FACTOR value

OUTPUT         : update port COUNT_PORT by input parameter 

NOTE           : 
-*------------------------------------------------------------*/
void Update_count(const tByte COUNT)
{
   COUNT_PORT = COUNT;
	/* reset total number of times timer T2 overflow interrupts occurs to 0, 
	   to avoid overflow of COUNT_PORT value , as COUNT_PORT is a 8 bit port(255 max value) */
	 if(COUNT >= MAX_COUNT) 
		 interruptT2_count = 0;
}

/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
