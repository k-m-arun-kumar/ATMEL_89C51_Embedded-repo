/**************************************************************************
   FILE          :    read_display.h
 
   PURPOSE       :    Type declarations for the read_display.c
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    read_display.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/

#ifndef _READ_DISPLAY_H
#define _READ_DISPLAY_H

#include "main.h"
// ------ Public function prototypes --------------------------
void Display_Byte(const tByte CH);
void Write_Bit(const tByte PIN, const bit VALUE);
bit Read_Bit(const tByte PIN);
#endif

/*------------------------------------------------------------*-
------------------------- END OF FILE --------------------------
-*------------------------------------------------------------*/
