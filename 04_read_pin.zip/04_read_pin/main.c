/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Program for the 8051 for Reading and writing bits of a pin 
                        in PORT P2 (generic version).
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : delay parameter is not fine tuned to get approx desired time delay.

NOTE                  : switch at 5th pin and led pin at 2nd pin are connected on the same port, PORT

CHANGE LOGS            :

*****************************************************************************/	

#include "main.h"
#include "port.h"
#include "read_display.h"
#include "delay.h"

/* ************** private constants *******************/
#define DELAY_PARA  (500U)

/* Logic of LED, depending on HW interfacing the led pin.
  in this case we use logic 1 to glow led on */
#define ON (1)
#define OFF (0)

/*------------------------------------------------------------*-
FUNCTION NANE  : main

DESCRIPTION    :  Read switch and write status of switch to LED. 
                  delay for a specific period so that LED responses to change of switch state.

INPUT          : none

OUTPUT         : status of switch is updated to LED.

NOTE           : I cannot view the printf() and putchar() output. 
-*------------------------------------------------------------*/
void main (void)
{
bit x;
tByte port_data = 0x00;
led_pin = OFF;	
while(1)
{
	
	/* Read Port PORT, Pin 5 */
   x = Read_Bit(SWITCH_PIN); 
	/* in our case we use logic 1 to glow led on, so state of led_pin is inverse state of switch.
           eg switch is in state 0, when pressed on by setting 0 on pin of the PORT^SWITCH_PIN ie P2^5 pin ,
   	, then led pin should be 1 to indicate on */
	/* Write complement of switch to Port PORT, Pin 2 */
   Write_Bit(LED_PIN,~x); 
	/* execution of printf() and putchar() got stuck, so even if switch changes its state,
    	LED does not changes its state as Read_Bit() and Write_Bit() are not executed */
	port_data = PORT;
	/* printf("%-20s", "PORT port status: ");
	 Display_Byte(port_data); */
	
	 Delay_Loop(DELAY_PARA);
}
}

/*------------------------------------------------------------
---- END OF FILE --------------------------------------------
------------------------------------------------------------*/
