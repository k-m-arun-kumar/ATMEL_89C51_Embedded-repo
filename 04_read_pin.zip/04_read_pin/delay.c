/* ********************************************************************
FILE                 : delay.c

PURPOSE              : Simple library for delay.   
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           :  

NOTE                 : Duration of function is highly variable!

CHANGE LOGS          :

*****************************************************************************/	
#include "main.h"
#include "port.h"
#include "delay.h"

/*------------------------------------------------------------*-
FUNCTION NAME      : Delay_Loop.

DESCRIPTION        : Delay duration varies with parameter.
Parameter is, *ROUGHLY*, the delay, in milliseconds,
on 12MHz 8051 (12 osc cycles).

INPUT              : DELAY_MS for to adjust for delay required for switch debounce.

OUTPUT             : 

NOTE               : You need to adjust the timing for your application!

-*------------------------------------------------------------*/
void Delay_Loop(const tWord DELAY_MS)
{
tWord x, y;
for (x = 0; x <= DELAY_MS; x++)
	for (y = 0; y <= 120; y++);	
}
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/

