/* ********************************************************************
FILE                  : read_display.c

PURPOSE               : Display given Byte in binary. write a given bit to PIN in P0 port.
                        Read a status of PIN in P0 port.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :

NOTE                  : Output of putchar() cannot be viewed. so Display_Byte()
                        cannot be used in embedded C. For Desktop C this function works.

CHANGE LOGS           :

*****************************************************************************/ 
#include "main.h"
#include "port.h"
#include "read_display.h"


/*------------------------------------------------------------*-
FUNCTION NAME  : Display_Byte

DESCRIPTION     : Display given Byte in binary.

INPUT          : byte that has to display in binary.

OUTPUT         : none

NOTE           : output of putchar() cannot be viewed. so this function
                 cannot be used in embedded C. For Desktop C this function works.
-*------------------------------------------------------------*/

void Display_Byte(const tByte CH)
{
unsigned char i, c = CH;
/* set most signifcant bit in byte to 1 and all other bits are set as 0, so Mask = 0x80 */	
unsigned char Mask = 0x01 << 7;
/* for 1st iteration, display status of 7th bit in ch, for 2nd iteration, display status of 6th bit in ch
  ..., 8th iteration, display status of least significant bit(0th) in ch */	
for (i = 1; i <= 8; i++)
{
	/* only the most signifcant bit in byte is checked to be 1 or 0 for each iteration */
   putchar(c & Mask ? '1' : '0');
	/* left shift by 1 for each iteration so that whole byte is displayed in binary */
   c <<= 1;
}
putchar('\n');
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to PORT's PIN, without affecting other pin status of port PORT.
                . 0 is the least pin value and 7 is the most pin value. 

INPUT          : PORT's PIN and its value to be written. 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit(const tByte PIN, const bit VALUE)
{
unsigned char p = 0x01; // 00000001
/* Left shift appropriate number of places, 
	 so for PIN = 2, then p = 00000100 */
p <<= PIN;
// If we want 1 to be written at this PIN
if (VALUE == 1)
{
	/* set 1 to PIN and all other pins of PORT port are unchanged */
PORT |= p; 
return;
}
/* If we want 0 output at this pin, then only that PIN of port PORT is set to 0
  and all other pins of port PORT are unchanged. */
p = ~p; // Complement
/* if PIN = 2, then p = 11111011 */
PORT &= p; // Bitwise AND
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Read_Bit

DESCRIPTION     : first write 1 to that PIN of port PORT ,before reading PIN status in PORT port. 
                 only PIN status is returned and other pins in PORT port are discarded.
                 0 is the least pin value and 7 is the most pin value. 

INPUT          :  PIN in P0 port

OUTPUT         : status of PIN in P0's port. 

NOTE           : 
-*------------------------------------------------------------*/
bit Read_Bit(const tByte PIN)
{
	bit  status;
unsigned char p = 0x01; // 00000001
/* Left shift appropriate number of places, 
	so for PIN = 5, then  p = 00100000 */ 
p <<= PIN;
/* Write a 1 to the PIN in PORT port (to set up for reading),
  without affecting status of other pins in PORT port.	*/
Write_Bit(PIN, 1);
/* Read the PIN in PORT port (bitwise AND) and return. only
	 PIN status is returned and status of other pins in PORT port are discarded */

 return (PORT & p); 
}


/*------------------------------------------------------------*-
------------------------- END OF FILE --------------------------
-*------------------------------------------------------------*/
